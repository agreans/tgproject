<?php
require_once __DIR__ . '/../src/bootstrap.php';
requireAdminAuth();

require_once __DIR__ . '/../src/TelegramAccount.php';

$accountManager = new TelegramAccount();
$accountId = (int)($_GET['id'] ?? 0);

if ($accountId > 0) {
    $accountManager->deleteAccount($accountId);
}

redirect('/accounts');

