<?php
/**
 * Configuration File
 * DO NOT commit this file with real credentials
 */

// Database Configuration
define('DB_TYPE', 'sqlite'); // 'sqlite' or 'mysql'
define('DB_PATH', __DIR__ . '/../data/userbot.db');
define('DB_HOST', 'localhost');
define('DB_NAME', 'telegram_userbot');
define('DB_USER', '');
define('DB_PASS', '');

// Admin Configuration
// Generate password hash using: php generate_password.php
define('ADMIN_PASSWORD_HASH', '$2y$10$YOUR_PASSWORD_HASH_HERE'); // Replace with generated hash

// Application Paths
define('BASE_PATH', dirname(__DIR__));
define('SESSIONS_PATH', BASE_PATH . '/account_sessions');
define('ADMIN_SESSIONS_PATH', BASE_PATH . '/sessions');
define('JOBS_PATH', BASE_PATH . '/jobs');
define('LOGS_PATH', BASE_PATH . '/logs');
define('DATA_PATH', BASE_PATH . '/data');

// MadelineProto Settings
define('MADELINE_SETTINGS', [
    'app_info' => [
        'api_id' => 0, // Will be set per account
        'api_hash' => '', // Will be set per account
    ],
    'logger' => [
        'logger' => 0, // Disable logger
    ],
    'updates' => [
        'handle_updates' => false, // We don't need updates
    ],
]);

// Application Settings
define('MAX_EXECUTION_TIME', 25); // Max seconds per worker run
define('DEFAULT_DELAY_MIN', 2);
define('DEFAULT_DELAY_MAX', 5);

// Timezone
date_default_timezone_set('UTC');

